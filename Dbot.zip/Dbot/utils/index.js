module.exports = {

    updatePlayerCount: (client, seconds) => {
        const interval = setInterval(function setStatus() {
            // You can change slot number
            status = `${GetNumPlayerIndices()}/48`
            // You can change type status
            client.user.setActivity(status,{type: 'WATCHING'})
            return setStatus;
        }(), seconds * 1000)
    }

}